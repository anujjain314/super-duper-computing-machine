import { Button } from "@mui/material";
import React, { Component, useState } from "react";
import HomeworkSet from "./HomeworkSet";

function Projects(props) {
  return (
    <div
      style={{
        border: "3px solid black",
        height: "200px",
        display: "flex",
        flexDirection: "row",
        gap: "20px",
        padding: "10px 20px",
      }}
    >
      <div
        style={{
          display: "flex",
          textAlign: "center",
          justifyContent: "center",
        }}
      >
        {props.projectName}
      </div>
      <div style={{ display: "flex" }}>list, of, authorized, users</div>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
        }}
      >
        <HomeworkSet homeworkName="HWSet1" />
        <HomeworkSet homeworkName="HWSet2" />
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "center",
            alignContent: "center",
          }}
        ></div>
      </div>
      <div>
        <Button>Join</Button>
      </div>
    </div>
  );
}

export default Projects;
